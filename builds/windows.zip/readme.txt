============================================================
           ARTLIST.IO TOOLS - WINDOWS EDITION
============================================================

Author: Mu_rpy
Version: artlistio-tools-v1.2

--- QUICK START ---

1. Ensure you have Windows 10/11.
2. Double-click: start.bat
3. Accept the license terms on the first run.

--- NOTES ---

* First run installs Python 3.14.2, FFmpeg, and Virtual Environments.
* Keep 'src' and 'start.bat' in the same folder.
* Videos save to: output\videos\
* Audio saves to: output\audio\

--- TROUBLESHOOTING ---

* If 'start.bat' closes instantly, run it via PowerShell 
  to see the error message.
* Ensure you have an active internet connection for 
  the initial setup.
============================================================